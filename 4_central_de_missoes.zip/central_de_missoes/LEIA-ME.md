# Central de Missões

Como rodar:

1. `flutter create .` dentro desta pasta (cria android, ios, web etc. sem apagar o que já existe)
2. `flutter pub get`
3. `dart pub global activate flutterfire_cli`
4. `firebase login`
5. `dart pub global run flutterfire_cli:flutterfire configure` (gera o `lib/firebase_options.dart`)
6. No console do Firebase, crie o Cloud Firestore em modo de teste
7. `flutter run -d chrome`

A collection usada é `missoes`, com os campos `titulo`, `dificuldade`, `pontos`, `concluida` e `data`.
