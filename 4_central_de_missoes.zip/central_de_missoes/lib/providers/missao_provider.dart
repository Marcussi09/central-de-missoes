import 'package:flutter/foundation.dart';
import '../models/missao.dart';
import '../services/missao_service.dart';

class MissaoProvider extends ChangeNotifier {
  final MissaoService _servico = MissaoService();
  List<Missao> missoes = [];
  bool carregando = false;

  int get pontosConquistados => missoes
      .where((missao) => missao.concluida)
      .fold(0, (soma, missao) => soma + missao.pontos);

  String _dataDeHoje() {
    final agora = DateTime.now();
    final dia = agora.day.toString().padLeft(2, '0');
    final mes = agora.month.toString().padLeft(2, '0');
    return '$dia/$mes/${agora.year}';
  }

  Future<void> carregar() async {
    carregando = true;
    notifyListeners();
    missoes = await _servico.buscarTodas();
    carregando = false;
    notifyListeners();
  }

  Future<void> cadastrar(String titulo, String dificuldade) async {
    final missao = Missao(
      titulo: titulo.trim(),
      dificuldade: dificuldade,
      pontos: Missao.pontosDaDificuldade(dificuldade),
      data: _dataDeHoje(),
    );
    await _servico.adicionar(missao);
    await carregar();
  }

  Future<int> concluir(Missao missao) async {
    missao.concluida = true;
    await _servico.atualizar(missao);
    await carregar();
    return missao.pontos;
  }

  Future<void> excluir(Missao missao) async {
    await _servico.excluir(missao.id!);
    await carregar();
  }
}
