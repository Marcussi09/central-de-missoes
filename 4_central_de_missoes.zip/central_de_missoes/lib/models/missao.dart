class Missao {
  String? id;
  String titulo;
  String dificuldade;
  int pontos;
  bool concluida;
  String data;

  Missao({
    this.id,
    required this.titulo,
    required this.dificuldade,
    required this.pontos,
    this.concluida = false,
    required this.data,
  });

  static int pontosDaDificuldade(String dificuldade) {
    if (dificuldade == 'Difícil') return 30;
    if (dificuldade == 'Médio') return 20;
    return 10;
  }

  String get estrelas {
    if (dificuldade == 'Difícil') return '⭐⭐⭐';
    if (dificuldade == 'Médio') return '⭐⭐';
    return '⭐';
  }

  String get status => concluida ? 'Concluída' : 'Pendente';

  Map<String, dynamic> toMap() => {
        'titulo': titulo,
        'dificuldade': dificuldade,
        'pontos': pontos,
        'concluida': concluida,
        'data': data,
      };

  factory Missao.fromMap(Map<String, dynamic> mapa, String id) => Missao(
        id: id,
        titulo: mapa['titulo'] ?? '',
        dificuldade: mapa['dificuldade'] ?? 'Fácil',
        pontos: mapa['pontos'] ?? 10,
        concluida: mapa['concluida'] ?? false,
        data: mapa['data'] ?? '',
      );
}
