import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/missao.dart';
import '../providers/missao_provider.dart';

class DetalhesPage extends StatelessWidget {
  final String id;
  const DetalhesPage({super.key, required this.id});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<MissaoProvider>();
    final encontradas = provider.missoes.where((m) => m.id == id);
    if (encontradas.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: const Text('DETALHES DA MISSÃO')),
        body: const Center(child: Text('Missão não encontrada.')),
      );
    }
    final Missao missao = encontradas.first;
    return Scaffold(
      appBar: AppBar(title: const Text('DETALHES DA MISSÃO')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Título:', style: TextStyle(fontWeight: FontWeight.bold)),
            Text(missao.titulo, style: const TextStyle(fontSize: 18)),
            const SizedBox(height: 16),
            const Text('Dificuldade:',
                style: TextStyle(fontWeight: FontWeight.bold)),
            Text('${missao.estrelas} ${missao.dificuldade}',
                style: const TextStyle(fontSize: 18)),
            const SizedBox(height: 16),
            const Text('Pontos:', style: TextStyle(fontWeight: FontWeight.bold)),
            Text('${missao.pontos}', style: const TextStyle(fontSize: 18)),
            const SizedBox(height: 16),
            const Text('Status:', style: TextStyle(fontWeight: FontWeight.bold)),
            Text(missao.status, style: const TextStyle(fontSize: 18)),
            const SizedBox(height: 16),
            const Text('Data:', style: TextStyle(fontWeight: FontWeight.bold)),
            Text(missao.data, style: const TextStyle(fontSize: 18)),
            const SizedBox(height: 24),
            if (!missao.concluida)
              FilledButton(
                onPressed: () async {
                  final pontos =
                      await context.read<MissaoProvider>().concluir(missao);
                  if (!context.mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                          'Missão concluída!\nVocê conquistou $pontos pontos.'),
                    ),
                  );
                },
                child: const Text('CONCLUIR MISSÃO'),
              ),
          ],
        ),
      ),
    );
  }
}
