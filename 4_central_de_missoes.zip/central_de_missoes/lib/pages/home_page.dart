import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/missao.dart';
import '../providers/missao_provider.dart';
import 'detalhes_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _titulo = TextEditingController();
  String _dificuldade = 'Fácil';

  @override
  void initState() {
    super.initState();
    context.read<MissaoProvider>().carregar();
  }

  @override
  void dispose() {
    _titulo.dispose();
    super.dispose();
  }

  Future<void> _cadastrar() async {
    if (_titulo.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Informe o título da missão.')),
      );
      return;
    }
    await context.read<MissaoProvider>().cadastrar(_titulo.text, _dificuldade);
    _titulo.clear();
  }

  Future<void> _concluir(Missao missao) async {
    final pontos = await context.read<MissaoProvider>().concluir(missao);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Missão concluída!\nVocê conquistou $pontos pontos.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<MissaoProvider>();
    return Scaffold(
      appBar: AppBar(title: const Text('CENTRAL DE MISSÕES')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: _titulo,
              decoration: const InputDecoration(
                labelText: 'Título da missão',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: _dificuldade,
              decoration: const InputDecoration(
                labelText: 'Dificuldade',
                border: OutlineInputBorder(),
              ),
              items: const ['Fácil', 'Médio', 'Difícil']
                  .map((item) =>
                      DropdownMenuItem(value: item, child: Text(item)))
                  .toList(),
              onChanged: (valor) => setState(() => _dificuldade = valor!),
            ),
            const SizedBox(height: 12),
            FilledButton(
              onPressed: _cadastrar,
              child: const Text('CADASTRAR MISSÃO'),
            ),
            const SizedBox(height: 16),
            Text(
              'PONTOS CONQUISTADOS: ${provider.pontosConquistados}',
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const Divider(),
            Expanded(
              child: provider.carregando && provider.missoes.isEmpty
                  ? const Center(child: CircularProgressIndicator())
                  : provider.missoes.isEmpty
                      ? const Center(child: Text('Nenhuma missão cadastrada.'))
                      : ListView.builder(
                          itemCount: provider.missoes.length,
                          itemBuilder: (context, indice) {
                            final missao = provider.missoes[indice];
                            return Card(
                              child: ListTile(
                                onTap: () => Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) =>
                                        DetalhesPage(id: missao.id!),
                                  ),
                                ),
                                title: Text(missao.titulo),
                                subtitle: Text(
                                  'Dificuldade: ${missao.estrelas}\n'
                                  'Pontos: ${missao.pontos}\n'
                                  'Status: ${missao.status}\n'
                                  'Data: ${missao.data}',
                                ),
                                isThreeLine: true,
                                trailing: Wrap(
                                  children: [
                                    if (!missao.concluida)
                                      TextButton(
                                        onPressed: () => _concluir(missao),
                                        child: const Text('CONCLUIR'),
                                      ),
                                    TextButton(
                                      onPressed: () => context
                                          .read<MissaoProvider>()
                                          .excluir(missao),
                                      child: const Text('EXCLUIR'),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
            ),
          ],
        ),
      ),
    );
  }
}
